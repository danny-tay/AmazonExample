package CucumberFramework.steps;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import junit.framework.Assert;

public class steps {
	WebDriver driver;
	
	@Before()
	public void setup() throws Throwable {
		System.setProperty("webdriver.chrome.driver", "/Users/danieltay/Desktop/Java workspace/chromedriver");
		
		this.driver = new ChromeDriver();
		this.driver.manage().window().maximize();
		this.driver.manage().timeouts().pageLoadTimeout(60, TimeUnit.SECONDS);
	}
	
	@After()
	public void teardown() {
		driver.quit();
	}
	
	@Given("^User access amazon\\.com$")
	public void user_access_amazon_com() throws Throwable {
		driver.get("https://www.amazon.com/");;
	}

	@When("^User search for rubber ducky$")
	public void user_search_for_rubber_ducky() throws Throwable {
		driver.findElement(By.xpath("//*[@id=\"twotabsearchtextbox\"]")).sendKeys("rubber ducky");
		Thread.sleep(2000);
		driver.findElement(By.xpath("//*[@id=\"nav-search\"]/form/div[2]/div/input")).click();
	}

	@When("^User select an item from the search result$")
	public void user_select_an_item_from_the_search_result() throws Throwable {
		Thread.sleep(2000);
		driver.findElement(By.xpath("//*[contains(text(),'rainbow yuango')]")).click();
	}
	
	@When("^User select the Add to Cart button$")
	public void user_select_the_Add_to_Cart_button() throws Throwable {
		Thread.sleep(2000);
		driver.findElement(By.xpath("//*[@id=\"add-to-cart-button\"]")).click();
	}
	
	@Then("^the first item is added to the cart$")
	public void the_first_item_is_added_to_the_cart() throws Throwable {
		Thread.sleep(2500);
		WebElement subtotal = driver.findElement(By.xpath("//*[contains(text(),'1 item')]"));
		Assert.assertEquals(true, subtotal.isDisplayed());
		Thread.sleep(4000);  // Let the tester actually see something!
	}
	
	@When("^User search for bubble soap$")
	public void user_search_for_bubble_soap() throws Throwable {
		driver.findElement(By.xpath("//*[@id=\"twotabsearchtextbox\"]")).sendKeys("bubble soap");
		Thread.sleep(2000);
		driver.findElement(By.xpath("//*[@id=\"nav-search\"]/form/div[2]/div/input")).click(); 
	}

	@When("^User select an item from the second search result$")
	public void user_select_an_item_from_the_second_search_result() throws Throwable {
		Thread.sleep(2000);
		driver.findElement(By.xpath("//*[contains(text(),'Bubble Solution')]")).click();
	}
	
	@Then("^the second item is added to the cart$")
	public void the_second_item_is_added_to_the_cart() throws Throwable {
		Thread.sleep(2500);
		WebElement subtotal = driver.findElement(By.xpath("//*[contains(text(),'2 items')]"));
		Assert.assertEquals(true, subtotal.isDisplayed());
		Thread.sleep(4000);  // Let the tester actually see something!
	}

	@When("^User select the the Cart button$")
	public void user_select_the_the_Cart_button() throws Throwable {
		Thread.sleep(2000);
		driver.findElement(By.xpath("//*[@id=\"nav-cart\"]/span[3]")).click();
	}

	@Then("^both items should be in the cart$")
	public void both_items_should_be_in_the_cart() throws Throwable {
		Thread.sleep(2500);
		WebElement subtotal = driver.findElement(By.xpath("//*[contains(text(),'2 items')]"));
		Assert.assertEquals(true, subtotal.isDisplayed());
		Thread.sleep(4000);  // Let the tester actually see something!
	}
}